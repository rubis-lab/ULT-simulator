#pragma once
class PlaneInfo
{
public:
	PlaneInfo(void);
	~PlaneInfo(void);
};

