#pragma once

#define _USE_MATH_DEFINES
