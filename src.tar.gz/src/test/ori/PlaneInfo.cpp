#include "PlaneInfo.h"


PlaneInfo::PlaneInfo(void)
{
}


PlaneInfo::~PlaneInfo(void)
{
}
