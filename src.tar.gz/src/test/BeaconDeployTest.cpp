#include <stdio.h>
#include "Setting.h"
#include "BeaconDeploy.h"

int main()
{
	BeaconList beacons;
	PlaneList planes;


	Setting.
}
